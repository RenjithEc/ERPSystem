package admin;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class StudentData {

    private final StringProperty ID;
    private final StringProperty firstName;
    private final StringProperty lastName;
    private final StringProperty emailID;
    private final StringProperty DOB;
    private final StringProperty c1ID;
    private final StringProperty c2ID;
    private final StringProperty c3ID;
    private final StringProperty c4ID;
    private final StringProperty c1Mark;
    private final StringProperty c2Mark;
    private final StringProperty c3Mark;
    private final StringProperty c4Mark;

    public StudentData(String id, String firstname, String lastname, String email, String dob, String c1id, String c2id, String c3id, String c4id, String c1mark, String c2mark, String c3mark, String c4mark){
        this.ID = new SimpleStringProperty(id);
        this.firstName = new SimpleStringProperty(firstname);
        this.lastName = new SimpleStringProperty(lastname);
        this.emailID = new SimpleStringProperty(email);
        this.DOB = new SimpleStringProperty(dob);
        this.c1ID = new SimpleStringProperty(c1id);
        this.c2ID = new SimpleStringProperty(c2id);
        this.c3ID = new SimpleStringProperty(c3id);
        this.c1Mark = new SimpleStringProperty(c1mark);
        this.c2Mark = new SimpleStringProperty(c2mark);
        this.c3Mark = new SimpleStringProperty(c3mark);
        this.c4ID = new SimpleStringProperty(c4id);
        this.c4Mark = new SimpleStringProperty(c4mark);

    }

    public String getID() {
        return ID.get();
    }

    public StringProperty IDProperty() {
        return ID;
    }

    public void setID(String ID) {
        this.ID.set(ID);
    }

    public String getFirstName() {
        return firstName.get();
    }

    public StringProperty firstNameProperty() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName.set(firstName);
    }

    public String getLastName() {
        return lastName.get();
    }

    public StringProperty lastNameProperty() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName.set(lastName);
    }

    public String getEmailID() {
        return emailID.get();
    }

    public StringProperty emailIDProperty() {
        return emailID;
    }

    public void setEmailID(String emailID) {
        this.emailID.set(emailID);
    }

    public String getDOB() {
        return DOB.get();
    }

    public StringProperty DOBProperty() {
        return DOB;
    }

    public void setDOB(String DOB) {
        this.DOB.set(DOB);
    }

    public String getC1ID() {
        return c1ID.get();
    }

    public StringProperty c1IDProperty() {
        return c1ID;
    }

    public void setC1ID(String c1ID) {
        this.c1ID.set(c1ID);
    }

    public String getC2ID() {
        return c2ID.get();
    }

    public StringProperty c2IDProperty() {
        return c2ID;
    }

    public void setC2ID(String c2ID) {
        this.c2ID.set(c2ID);
    }

    public String getC3ID() {
        return c3ID.get();
    }

    public StringProperty c3IDProperty() {
        return c3ID;
    }

    public void setC3ID(String c3ID) {
        this.c3ID.set(c3ID);
    }

    public String getC4ID() {
        return c4ID.get();
    }

    public StringProperty c4IDProperty() {
        return c4ID;
    }

    public void setC4ID(String c4ID) {
        this.c4ID.set(c4ID);
    }

    public String getC1Mark() {
        return c1Mark.get();
    }

    public StringProperty c1MarkProperty() {
        return c1Mark;
    }

    public void setC1Mark(String c1Mark) {
        this.c1Mark.set(c1Mark);
    }

    public String getC2Mark() {
        return c2Mark.get();
    }

    public StringProperty c2MarkProperty() {
        return c2Mark;
    }

    public void setC2Mark(String c2Mark) {
        this.c2Mark.set(c2Mark);
    }

    public String getC3Mark() {
        return c3Mark.get();
    }

    public StringProperty c3MarkProperty() {
        return c3Mark;
    }

    public void setC3Mark(String c3Mark) {
        this.c3Mark.set(c3Mark);
    }

    public String getC4Mark() {
        return c4Mark.get();
    }

    public StringProperty c4MarkProperty() {
        return c4Mark;
    }

    public void setC4Mark(String c4Mark) {
        this.c4Mark.set(c4Mark);
    }
}
