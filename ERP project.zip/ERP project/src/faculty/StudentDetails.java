package faculty;

public class StudentDetails {
}
