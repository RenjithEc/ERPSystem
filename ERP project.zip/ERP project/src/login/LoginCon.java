package login;

import admin.AdminCon;
import faculty.FacultyCon;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import students.StudentsCon;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class LoginCon implements Initializable {

    LoginMod loginMod = new LoginMod();

    @FXML
    private Label dbstatus;
    @FXML
    private TextField username;
    @FXML
    private PasswordField password;
    @FXML
    private ComboBox<option> combo;
    @FXML
    private Button loginbutton;
    @FXML
    private  Label loginstatus;

    public void initialize(URL url, ResourceBundle rb){
        if(this.loginMod.isDatabaseConnected()){
            this.dbstatus.setText("Connected");
        } else this.dbstatus.setText("Not Connected");

        this.combo.setItems(FXCollections.observableArrayList(option.values()));
    }

    @FXML
    public void Login(ActionEvent event){
         try {
             if(this.loginMod.isLogin(this.username.getText(), this.password.getText(), ((option)this.combo.getValue()).toString())){
                 Stage stage=(Stage)this.loginbutton.getScene().getWindow();
                 stage.close();
                 switch (((option)this.combo.getValue()).toString()){
                     case "Admin":
                         adminLogin();
                         break;
                     case "Student":
                         studentLogin();
                         break;
                     case "Faculty":
                         facultylogin();
                         break;
                 }
             }
             else {
                 this.loginstatus.setText("Wrong Credentials!!!");
             }


         }catch (Exception localExecption){

         }

    }
    public void studentLogin(){
        try{
            Stage userstage = new Stage();
            FXMLLoader loader= new FXMLLoader();
            Pane root =(Pane)loader.load(getClass().getResource("/students/studentFXML.fxml").openStream());

            StudentsCon studentsCon = (StudentsCon)loader.getController();

            Scene scene= new Scene(root);
            userstage.setScene(scene);
            userstage.setTitle("Student Dashboard");
            userstage.setResizable(false);
            userstage.show();

        } catch(IOException ex){
            ex.printStackTrace();
        }
    }

    public void adminLogin(){
        try{
            Stage adminstage = new Stage();
            FXMLLoader adminloader= new FXMLLoader();
            Pane root =(Pane)adminloader.load(getClass().getResource("/admin/adminFXML.fxml").openStream());

            AdminCon adminCon = (AdminCon)adminloader.getController();

            Scene scene= new Scene(root);
            adminstage.setScene(scene);
            adminstage.setTitle("Admin Dashboard");
            adminstage.setResizable(false);
            adminstage.show();

        }catch (IOException e){
            e.printStackTrace();
        }

    }
    public void facultylogin(){
        try{
            Stage facstage = new Stage();
            FXMLLoader facloader= new FXMLLoader();
            Pane root =(Pane)facloader.load(getClass().getResource("/faculty/facFXML.fxml").openStream());

            FacultyCon facultyCon = (FacultyCon) facloader.getController();

            Scene scene= new Scene(root);
            facstage.setScene(scene);
            facstage.setTitle("Faculty Dashboard");
            facstage.setResizable(false);
            facstage.show();

        }catch (IOException exc){
            exc.printStackTrace();
        }

    }


}

