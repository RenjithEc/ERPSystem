package students;

import admin.StudentData;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

import database.dbconn;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;


public class StudentsCon implements Initializable {

    @FXML
    private TextField id;
    @FXML
    private TableView<StudentData> studenttable;

    @FXML
    private TableColumn<StudentData, String>idcol;
    @FXML
    private TableColumn<StudentData, String>fnamecol;
    @FXML
    private TableColumn<StudentData, String>lnamecol;
    @FXML
    private TableColumn<StudentData, String>emailcol;
    @FXML
    private TableColumn<StudentData, String>dobcol;

    @FXML
    private TableColumn<StudentData, String>c1col;
    @FXML
    private TableColumn<StudentData, String>c2col;
    @FXML
    private TableColumn<StudentData, String>c3col;
    @FXML
    private TableColumn<StudentData, String>m1col;
    @FXML
    private TableColumn<StudentData, String>m2col;
    @FXML
    private TableColumn<StudentData, String>m3col;

    private dbconn db;
    private ObservableList<StudentData>data;



    public void initialize(URL url, ResourceBundle rb){
        this.db = new dbconn();
    }

    @FXML
    private void loadStudentData(ActionEvent event)throws SQLException {
        String sql = "SELECT * FROM students WHERE id = ?";
        try {
            Connection conn = dbconn.getConnection();
            this.data = FXCollections.observableArrayList();
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, this.id.getText());

            stmt.execute();
            ResultSet rs = conn.createStatement().executeQuery(sql);
            while (rs.next()) {
                this.data.add(new StudentData(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7), rs.getString(8), rs.getString(9), rs.getString(10), rs.getString(11),rs.getString(12),rs.getString(13)));
            }
            conn.close();

        } catch (SQLException ee) {
            System.err.println("ERROR" + ee);
        }
        this.idcol.setCellValueFactory(new PropertyValueFactory<StudentData, String>("ID"));
        this.fnamecol.setCellValueFactory(new PropertyValueFactory<StudentData, String>("firstName"));
        this.lnamecol.setCellValueFactory(new PropertyValueFactory<StudentData, String>("lastName"));
        this.emailcol.setCellValueFactory(new PropertyValueFactory<StudentData, String>("emailID"));
        this.dobcol.setCellValueFactory(new PropertyValueFactory<StudentData, String>("DOB"));

        this.c1col.setCellValueFactory(new PropertyValueFactory<StudentData, String>("c1ID"));
        this.c2col.setCellValueFactory(new PropertyValueFactory<StudentData, String>("c2ID"));
        this.c3col.setCellValueFactory(new PropertyValueFactory<StudentData, String>("c3ID"));
        this.m1col.setCellValueFactory(new PropertyValueFactory<StudentData, String>("c1Mark"));
        this.m2col.setCellValueFactory(new PropertyValueFactory<StudentData, String>("c2Mark"));
        this.m3col.setCellValueFactory(new PropertyValueFactory<StudentData, String>("c3Mark"));

        this.studenttable.setItems(null);
        this.studenttable.setItems(this.data);
    }


    @FXML
    private  void clearfield(ActionEvent event){
        this.id.setText("");

    }


}
